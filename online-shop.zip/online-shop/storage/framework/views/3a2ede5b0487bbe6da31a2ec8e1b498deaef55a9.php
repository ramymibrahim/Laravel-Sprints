
<?php $__env->startSection('content'); ?>
    <h2>Show Category</h2>
    
        <label>Name</label>
        <h3><?php echo e($category->name); ?></h3>
        <img src="<?php echo e(asset('storage/'.$category->image)); ?>" />
        <a class="btn btn-secondary" href="<?php echo e(url('admin/categories')); ?>">Cancel</a>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\RamyIbrahim\Desktop\Laravel\online-shop\resources\views/admin/categories/show.blade.php ENDPATH**/ ?>