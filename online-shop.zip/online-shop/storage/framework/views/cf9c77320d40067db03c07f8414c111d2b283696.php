
<?php $__env->startSection('content'); ?>
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success alert-block">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <strong><?php echo e($message); ?></strong>
        </div>
    <?php endif; ?>
    <a class="btn btn-success" href="<?php echo e(url('admin/products/create')); ?>">Add</a>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Category</th>
                <th colspan="3">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($product['id']); ?></td>
                    <td><?php echo e($product['name']); ?></td>
                    <td><?php echo e($product['category']['name']); ?></td>
                    <td><a href="<?php echo e(url('admin/products/' . $product['id'])); ?>">Show</a></td>
                    <td><a href="<?php echo e(url('admin/products/' . $product['id'] . '/edit')); ?>">Edit</a></td>
                    <td>
                        <form action="<?php echo e(url('admin/products/' . $product['id'])); ?>" method="POST">
                            <?php echo method_field('DELETE'); ?>
                            <?php echo csrf_field(); ?>
                            <button onclick="return confirm('Are you sure?')" class="btn btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
    <?php echo $products->links(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\RamyIbrahim\Desktop\Laravel\online-shop\resources\views/admin/products/index.blade.php ENDPATH**/ ?>