
<?php $__env->startSection('content'); ?>
    <h2>Add Product</h2>
    <form method="POST" action="<?php echo e(url('admin/products')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <label>Name</label>
        <input class="form-control" name="name" value="<?php echo e(old('name')); ?>" />
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <label>Description</label>
        <textarea class="form-control" name="description"><?php echo e(old('description')); ?></textarea>
        <label>Price</label>
        <input class="form-control" name="price" type="number" value="<?php echo e(old('price')); ?>" />
        <label>Discount</label>
        <input class="form-control" name="discount" type="number" value="<?php echo e(old('discout')); ?>" step="0.01" />
        <label>Is Recent <input name="is_recent" type="checkbox" <?php echo e(old('is_recent') ? 'checked' : ''); ?> /></label>
        <br />
        <label>Is Featured <input name="is_featured" type="checkbox" <?php echo e(old('is_featured') ? 'checked' : ''); ?> /></label>
        <br />
        <label>Image</label>
        <input  name="image" type="file" value="<?php echo e(old('image')); ?>" />
        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <label>Category</label>
        <select class="form-control" name="category_id">
            <option>Select Category</option>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->id); ?>" <?php echo e(old('category_id') == $category['id'] ? 'selected' : ''); ?>>
                    <?php echo e($category->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <label>Color</label>
        <select class="form-control" name="color_id">
            <option>Select Color</option>
            <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($color->id); ?>" <?php echo e(old('color_id') == $color['id'] ? 'selected' : ''); ?>><?php echo e($color->name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <label>Size</label>
        <select class="form-control" name="size_id">
            <option>Select Size</option>
            <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($size->id); ?>" <?php echo e(old('size_id') == $size['id'] ? 'selected' : ''); ?>><?php echo e($size->name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <button class="btn btn-primary">Add</button>
        <a class="btn btn-secondary" href="<?php echo e(url('admin/products')); ?>">Cancel</a>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\RamyIbrahim\Desktop\Laravel\online-shop\resources\views/admin/products/create.blade.php ENDPATH**/ ?>